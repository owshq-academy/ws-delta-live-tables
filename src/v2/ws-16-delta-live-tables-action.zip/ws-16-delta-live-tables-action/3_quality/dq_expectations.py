import dlt
from pyspark.sql.functions import *
from pyspark.sql.types import *

user_schema = StructType([
    StructField("user_id", IntegerType(), True),
    StructField("country", StringType(), True),
    StructField("city", StringType(), True),
    StructField("phone_number", StringType(), True),
    StructField("email", StringType(), True),
    StructField("uuid", StringType(), True),
    StructField("delivery_address", StringType(), True),
    StructField("user_identifier", StringType(), True),
    StructField("dt_current_timestamp", StringType(), True)
])

raw_expectations = {
    "valid_user_id": "user_id IS NOT NULL",
    "valid_country": "country IS NOT NULL AND country = 'BR'",
    "valid_email": "email IS NOT NULL AND email LIKE '%@%.%'",
    "valid_timestamp_format": "dt_current_timestamp IS NOT NULL"
}

prepared_expectations = {
    "valid_phone_format": """
        phone_number RLIKE '\\(\\d{2}\\)\\s\\d{4}-\\d{4}'
    """,
    "valid_user_identifier_format": """
        user_identifier RLIKE '\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}'
    """,
    "valid_uuid_format": """
        uuid RLIKE '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    """
}

business_expectations = {
    "valid_address_components": """
        delivery_address IS NOT NULL 
        AND length(delivery_address) >= 10
        AND delivery_address RLIKE '.*,.*,.*\\d{5}-\\d{3}'
    """,
    "valid_city_country_combination": """
        CASE 
            WHEN country = 'BR' THEN city IS NOT NULL AND length(city) >= 2
            ELSE FALSE 
        END
    """,
    "valid_timestamp_range": """
        timestamp >= '2024-01-01' 
        AND timestamp <= current_timestamp()
    """
}

# 1. Bronze
@dlt.table(
    name="bronze_storage_users",
    comment="Raw Users Data with Basic Quality Checks"
)
@dlt.expect_all(raw_expectations)
def bronze_storage_users():
    return (
        spark.readStream
            .format("json")
            .schema(user_schema)
            .load("dbfs:/mnt/owshq-shadow-traffic/mongodb/users/")
    )

# 2. Silver
@dlt.table(
    name="silver_users",
    comment="Cleansed Users Data with Advanced Format Validations"
)
@dlt.expect_all_or_drop(prepared_expectations)
def silver_users():
    return (
        dlt.read_stream("bronze_storage_users")
        .withColumn("timestamp", to_timestamp("dt_current_timestamp"))
        .withColumn("email_normalized", lower(col("email")))
        .select(
            "user_id",
            "country",
            "city",
            "phone_number",
            "email_normalized",
            "uuid",
            "delivery_address",
            "user_identifier",
            "timestamp"
        )
    )

# 3. Gold
@dlt.table(
    name="gold_users",
    comment="Business-Ready Users Data with Complex Business Rule Validations"
)
@dlt.expect_all_or_fail(business_expectations)
def gold_users():
    return (
        dlt.read_stream("silver_users")
        .withColumn("date", date_format("timestamp", "yyyy-MM-dd"))
        .withColumn("time", date_format("timestamp", "HH:mm:ss"))
    )

# 4. Quarantine
@dlt.table(
    name="quarantine_users",
    comment="Records Failed Silver Layer Validations"
)
@dlt.expect_or_drop(
    "has_validation_errors",
    """
    NOT(phone_number RLIKE '\\(\\d{2}\\)\\s\\d{4}-\\d{4}')
    OR NOT(user_identifier RLIKE '\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}')
    OR NOT(uuid RLIKE '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
    """
)
def quarantine_users():
    return (
        dlt.read_stream("bronze_storage_users")
        .select(
            "user_id",
            "country",
            "city",
            "phone_number", 
            "email",
            "uuid",
            "delivery_address",
            "user_identifier",
            "dt_current_timestamp"
        )
    )

# 5. Metrics
@dlt.table(
    name="metric_users",
    comment="Basic Data Quality Metrics"
)
def data_quality_metrics():
    return (
        dlt.read("bronze_storage_users")
        .select(
            "country",
            col("user_id").isNotNull().alias("has_user_id"),
            col("email").like("%@%.%").alias("has_valid_email")
        )
        .groupBy("country")
        .agg(
            count("*").alias("total_records"),
            sum(when(col("has_user_id"), 1).otherwise(0)).alias("valid_user_ids"),
            sum(when(col("has_valid_email"), 1).otherwise(0)).alias("valid_emails")
        )
    )