import dlt
from pyspark.sql.functions import (
    col, 
    to_timestamp,
    current_timestamp,
    year,
    month,
    dayofmonth,
    hour,
    from_unixtime,
    expr
)
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    TimestampType,
    DoubleType
)

order_schema = StructType([
    StructField("order_id", StringType(), True),
    StructField("user_key", StringType(), True),
    StructField("restaurant_key", StringType(), True),
    StructField("driver_key", StringType(), True),
    StructField("order_date", TimestampType(), True),
    StructField("total_amount", DoubleType(), True),
    StructField("payment_id", StringType(), True),
    StructField("dt_current_timestamp", TimestampType(), True)
])

@dlt.table(
    name="silver_orders",
    table_properties={
        "quality": "silver",
        "pipelines.autoOptimize.managed": "true"
    }
)
def silver_orders():
    return (
        dlt.read_stream("bronze_storage_orders")
        .select(
            col("order_id"),
            col("user_key"),
            col("restaurant_key"),
            col("driver_key"),
            to_timestamp(col("order_date")).alias("order_date"),
            col("total_amount"),
            col("payment_id"),
            to_timestamp(col("dt_current_timestamp")).alias("dt_current_timestamp"),
            year(col("order_date")).alias("year"),
            month(col("order_date")).alias("month"),
            dayofmonth(col("order_date")).alias("day"),
            hour(col("order_date")).alias("hour")
        )
        .filter(col("order_id").isNotNull())
        .filter(col("total_amount") > 0)
    )

@dlt.table(
    name="gold_daily_metrics",
    table_properties={
        "quality": "gold",
        "pipelines.autoOptimize.managed": "true"
    }
)
def gold_daily_metrics():
    return (
        dlt.read("silver_orders")
        .groupBy("year", "month", "day")
        .agg(
            expr("count(distinct order_id)").alias("total_orders"),
            expr("count(distinct user_key)").alias("unique_customers"),
            expr("count(distinct restaurant_key)").alias("active_restaurants"),
            expr("count(distinct driver_key)").alias("active_drivers"),
            expr("sum(total_amount)").alias("total_revenue"),
            expr("avg(total_amount)").alias("avg_order_value")
        )
    )

@dlt.table(
    name="gold_restaurant_metrics",
    table_properties={
        "quality": "gold",
        "pipelines.autoOptimize.managed": "true"
    }
)
def gold_restaurant_metrics():
    return (
        dlt.read("silver_orders")
        .groupBy("restaurant_key", "year", "month")
        .agg(
            expr("count(distinct order_id)").alias("total_orders"),
            expr("sum(total_amount)").alias("total_revenue"),
            expr("avg(total_amount)").alias("avg_order_value"),
            expr("count(distinct user_key)").alias("unique_customers")
        )
    )
