CREATE OR REFRESH LIVE TABLE bronze_storage_drivers
AS SELECT 
  license_number as driver_key,
  first_name,
  last_name,
  vehicle_type,
  vehicle_type AS type_vec
FROM json.`dbfs:/mnt/owshq-shadow-traffic/postgres/drivers`;

CREATE OR REFRESH STREAMING LIVE TABLE silver_orders_totals
AS SELECT 
  o.order_id,
  o.order_date,
  o.total_amount,
  d.first_name,
  d.last_name,
  d.vehicle_type,
  d.type_vec
FROM STREAM(bronze_storage_orders) o
LEFT JOIN bronze_storage_drivers d
  ON o.driver_key = d.driver_key;
