"""
Order Status Tracking Pipeline using Delta Live Tables and Metaprogramming
=======================================================================

This module implements an automated data pipeline using Delta Live Tables (DLT) to process
and analyze order status data. It leverages Python metaprogramming to dynamically create
status-specific tables, providing a scalable solution for order status tracking.

Key Components:
-------------
1. Status-specific Silver Tables: Individual tables for each order status
2. Gold Summary Table: Aggregated metrics across all statuses

Data Flow:
---------
Bronze (Raw Data) → Silver (Status-Specific) → Gold (Summary Metrics)
"""

import dlt
from pyspark.sql.functions import *

status_list = [
    "Order Placed",
    "In Analysis",
    "Accepted",
    "Preparing",
    "Ready for Pickup",
    "Picked Up",
    "Out for Delivery",
    "Delivered",
    "Completed"
]

def create_status_table(status_name):
    """
    Dynamically creates a Delta Live Table for a specific order status using metaprogramming.
    
    This function demonstrates the power of Python metaprogramming by generating separate
    tables for each order status. It automatically handles timestamp conversions and
    data filtering.
    
    Args:
        status_name (str): The specific order status to create a table for
        
    Generated Table Schema:
    ---------------------
    - status_id (str): Unique identifier for the status event
    - order_identifier (str): Unique identifier for the order
    - status_name (str): Name of the order status
    - status_timestamp (timestamp): When the status was recorded (converted from Unix)
    - current_timestamp (timestamp): Processing timestamp
    """
    table_name = f"silver_status_{status_name.lower().replace(' ', '_')}"
    
    @dlt.table(
        name=table_name,
        comment=f"Orders with Status: {status_name}"
    )
    def create_table():
        """
        Inner function that defines the table transformation logic.
        Uses LIVE.bronze_storage_status as source and filters for specific status.
        """
        return spark.sql(f"""
            SELECT 
                status_id,
                order_identifier,
                status.status_name,
                CAST(status.timestamp / 1000 AS TIMESTAMP) as status_timestamp,
                CAST(dt_current_timestamp AS TIMESTAMP) as current_timestamp
            FROM LIVE.bronze_storage_status
            WHERE status.status_name = '{status_name}'
        """)

for status in status_list:
    create_status_table(status)

@dlt.table(
    name="gold_orders_status_summary",
    comment="Gold Table with Summary Metrics of Status Types"
)
def create_summary_table():
    """
    Creates a gold-layer summary table with aggregated metrics for all order statuses.
    
    This table provides analytical insights including:
    - Total order count per status
    - Time range analysis (earliest/latest status updates)
    - Unique order counts
    
    Schema:
    -------
    - status_name (str): Name of the order status
    - total_orders (long): Count of status events
    - earliest_status (timestamp): First occurrence of this status
    - latest_status (timestamp): Most recent occurrence of this status
    - unique_orders (long): Count of distinct orders
    """
    return spark.sql("""
        SELECT 
            status.status_name,
            COUNT(*) as total_orders,
            MIN(CAST(status.timestamp / 1000 AS TIMESTAMP)) as earliest_status,
            MAX(CAST(status.timestamp / 1000 AS TIMESTAMP)) as latest_status,
            COUNT(DISTINCT order_identifier) as unique_orders
        FROM LIVE.bronze_storage_status
        GROUP BY status.status_name
        ORDER BY status.status_name
    """)
  