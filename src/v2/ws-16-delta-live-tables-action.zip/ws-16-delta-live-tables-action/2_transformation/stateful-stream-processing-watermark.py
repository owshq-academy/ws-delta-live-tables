import dlt
from pyspark.sql.functions import (
    col, 
    expr,
    to_timestamp,
    window,
    current_timestamp
)
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    IntegerType,
    DoubleType,
    TimestampType
)

orders_schema = StructType([
    StructField("order_id", StringType(), True),
    StructField("user_key", StringType(), True),
    StructField("restaurant_key", StringType(), True),
    StructField("driver_key", StringType(), True),
    StructField("order_date", StringType(), True),
    StructField("total_amount", DoubleType(), True),
    StructField("payment_id", StringType(), True),
    StructField("dt_current_timestamp", StringType(), True)
])

status_schema = StructType([
    StructField("status_id", IntegerType(), True),
    StructField("order_identifier", StringType(), True),
    StructField("status", StructType([
        StructField("status_name", StringType(), True),
        StructField("timestamp", DoubleType(), True)
    ]), True),
    StructField("dt_current_timestamp", StringType(), True)
])

@dlt.table(
    name="bronze_storage_orders_watermark",
)
def bronze_storage_orders_watermark():
    return (
        spark.readStream
        .format("cloudFiles")
        .option("cloudFiles.format", "json")
        .schema(orders_schema)
        .load("dbfs:/mnt/owshq-shadow-traffic/kafka/orders")
        .select(
            col("order_id"),
            col("user_key"),
            col("restaurant_key"),
            col("driver_key"),
            to_timestamp(col("order_date")).alias("order_timestamp"),
            col("total_amount"),
            col("payment_id"),
            to_timestamp(col("dt_current_timestamp")).alias("processed_at")
        )
    )

@dlt.table(
    name="bronze_storage_status_watermark",
)
def bronze_storage_status_watermark():
    return (
        spark.readStream
        .format("cloudFiles")
        .option("cloudFiles.format", "json")
        .schema(status_schema)
        .load("dbfs:/mnt/owshq-shadow-traffic/kafka/status")
        .select(
            col("status_id"),
            col("order_identifier").alias("order_id"),
            col("status.status_name").alias("status_name"),
            to_timestamp(col("status.timestamp")/1000).alias("status_timestamp"),
            to_timestamp(col("dt_current_timestamp")).alias("processed_at")
        )
    )

@dlt.table(
    name="silver_status_watermark",
)
def silver_status_watermark():
    return (
        dlt.read_stream("bronze_storage_status_watermark")
        .withWatermark("status_timestamp", "10 minutes")
        .dropDuplicates(["order_id", "status_name", "status_timestamp"])
    )

@dlt.table(
    name="gold_orders_status_watermark",
)
def gold_orders_status_watermark():

    orders_stream = (
        dlt.read_stream("bronze_storage_orders_watermark")
        .withWatermark("order_timestamp", "10 minutes")
    )
    
    status_stream = (
        dlt.read_stream("bronze_storage_status_watermark")
        .withWatermark("status_timestamp", "10 minutes")
    )
    
    join_condition = [
        orders_stream.order_id == status_stream.order_id,
        status_stream.status_timestamp >= orders_stream.order_timestamp,
        status_stream.status_timestamp <= orders_stream.order_timestamp + expr("interval 2 hours")
    ]
    
    return (
        orders_stream.join(
            status_stream,
            join_condition,
            "inner"
        )
        .select(
            orders_stream.order_id,
            orders_stream.order_timestamp,
            status_stream.status_timestamp,
            status_stream.status_name,
            orders_stream.total_amount
        )
    )

@dlt.table(
    name="gold_status_metrics_watermark"
)
def gold_status_metrics_watermark():
    return (
        dlt.read_stream("gold_orders_status_watermark")
        .withWatermark("status_timestamp", "15 minutes")
        .groupBy(
            window("status_timestamp", "15 minutes"),
            "status_name"
        )
        .agg(
            expr("count(distinct order_id)").alias("order_count"),
            expr("sum(total_amount)").alias("total_amount"),
            expr("avg(total_amount)").alias("avg_amount")
        )
    )