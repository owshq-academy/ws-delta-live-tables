CREATE OR REFRESH STREAMING TABLE bronze_storage_orders
AS 
SELECT *, _metadata.*
FROM STREAM read_files('dbfs:/mnt/owshq-shadow-traffic/kafka/orders/', format => 'json');

CREATE OR REFRESH STREAMING TABLE bronze_storage_status
AS 
SELECT *, _metadata.*
FROM STREAM read_files('dbfs:/mnt/owshq-shadow-traffic/kafka/status/', format => 'json');