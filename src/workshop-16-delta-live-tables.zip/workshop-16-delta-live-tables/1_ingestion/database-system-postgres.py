import dlt

table_name = 'public.drivers'
host_url = 'owshq-postgres-streams-dev-do-user-10267601-0.m.db.ondigitalocean.com'
port = '25060'
database_name = 'owshq'
username = 'doadmin' 
password = 'AVNS_qcSrg-yozCn5_eLTcVF'

@dlt.table
def ws_bronze_postgres_drivers():
  return (
    spark.read
      .format("postgresql")
      .option("dbtable", table_name)
      .option("host", host_url)
      .option("port", port)
      .option("database", database_name)
      .option("user", username)
      .option("password", password)
      .load()
  )
  