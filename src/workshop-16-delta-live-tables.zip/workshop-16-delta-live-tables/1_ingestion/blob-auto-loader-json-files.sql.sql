-- Databricks notebook source
CREATE OR REFRESH STREAMING TABLE ws_bronze_storage_orders
AS
SELECT *
FROM STREAM read_files('dbfs:/mnt/owshq-shadow-traffic/kafka/orders/', format => 'json');

-- COMMAND ----------

CREATE OR REFRESH STREAMING TABLE ws_bronze_storage_status
AS 
SELECT * 
FROM STREAM read_files('dbfs:/mnt/owshq-shadow-traffic/kafka/status/', format => 'json');