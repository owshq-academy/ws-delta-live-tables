import dlt
from pyspark.sql.functions import (
    col, 
    expr, 
    from_json, 
    current_timestamp, 
    lit, 
    when,
    coalesce
)
from pyspark.sql.types import StructType, StructField, StringType, TimestampType

cdc_schema = StructType([
    StructField("op", StringType(), True),
    StructField("payload", StructType([
        StructField("before", StructType([
            StructField("id", StringType(), True),
            StructField("firstName", StringType(), True),
            StructField("lastName", StringType(), True),
            StructField("email", StringType(), True)
        ]), True),
        StructField("after", StructType([
            StructField("id", StringType(), True),
            StructField("firstName", StringType(), True),
            StructField("lastName", StringType(), True),
            StructField("email", StringType(), True)
        ]), True)
    ]), True)
])

@dlt.view
def events():
    df = (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "json")
        .schema(cdc_schema)
        .load("dbfs:/mnt/owshq-shadow-traffic/events/")
    )
    
    updates_before = df.filter(col("op") == "u").select(
        lit("d").alias("operation"),
        col("payload.before.id").alias("id"),
        col("payload.before.firstName").alias("firstName"),
        col("payload.before.lastName").alias("lastName"),
        col("payload.before.email").alias("email"),
        current_timestamp().alias("sequenceNum")
    )
    
    updates_after = df.filter(col("op") == "u").select(
        lit("c").alias("operation"),
        col("payload.after.id").alias("id"),
        col("payload.after.firstName").alias("firstName"),
        col("payload.after.lastName").alias("lastName"),
        col("payload.after.email").alias("email"),
        current_timestamp().alias("sequenceNum")
    )
    
    other_operations = df.filter(col("op") != "u").select(
        col("op").alias("operation"),
        coalesce(col("payload.after.id"), col("payload.before.id")).alias("id"),
        coalesce(col("payload.after.firstName"), col("payload.before.firstName")).alias("firstName"),
        coalesce(col("payload.after.lastName"), col("payload.before.lastName")).alias("lastName"),
        coalesce(col("payload.after.email"), col("payload.before.email")).alias("email"),
        current_timestamp().alias("sequenceNum")
    )
    
    return updates_before.unionAll(updates_after).unionAll(other_operations)

dlt.create_streaming_table(
    name="bronze_storage_events",
    comment="SCD Type 2 Table for Events History"
)

dlt.apply_changes(
    target="bronze_storage_events",
    source="events",
    keys=["id"],
    sequence_by=col("sequenceNum"),
    apply_as_deletes=expr("operation = 'd'"),
    except_column_list=[
        "operation",
        "sequenceNum"
    ],
    stored_as_scd_type="2",
    track_history_column_list=[
        "firstName",
        "lastName",
        "email"
    ]
)